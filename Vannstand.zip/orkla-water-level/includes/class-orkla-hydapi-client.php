<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @deprecated HydAPI integration has been removed. This stub remains for backward compatibility.
 */
class Orkla_Hydapi_Client {}
